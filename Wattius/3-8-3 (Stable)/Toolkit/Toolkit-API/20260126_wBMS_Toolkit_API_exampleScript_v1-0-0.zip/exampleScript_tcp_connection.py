from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *

print(wbms_set_connection_tcp(input("\nEnter BMU IP address (i.e. 192.168.1.105): ")))