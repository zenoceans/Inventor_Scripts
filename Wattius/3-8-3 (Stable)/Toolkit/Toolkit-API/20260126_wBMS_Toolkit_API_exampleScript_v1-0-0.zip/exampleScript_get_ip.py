from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *
import time

timeout = 30
start = time.monotonic()
result = wbms_result.OK
ip_address = "0.0.0.0"
while ((result == wbms_result.WAITING) | (result == wbms_result.OK) | (ip_address == "0.0.0.0")):
    if time.monotonic() - start > timeout:
        raise TimeoutError("IP don't get in time")
    result = wbms_get_ip()
    if ((result != wbms_result.WAITING) & (result != wbms_result.OK)):
        ip_address_parts = result.decode("utf-8").split('.')
        ip_address = str(int(ip_address_parts[0])) + "." + str(int(ip_address_parts[1])) + "." + str(int(ip_address_parts[2])) + "." + str(int(ip_address_parts[3]))

print("IP: " + ip_address)