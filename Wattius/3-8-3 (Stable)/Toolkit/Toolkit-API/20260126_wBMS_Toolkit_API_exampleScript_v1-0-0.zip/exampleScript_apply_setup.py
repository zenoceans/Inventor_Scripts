from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *
import time

def apply_bmu_setup(setup_can_baudrate, setup_can_node_id, setup_bluetooth_mode, setup_network_mode, setup_static_ip_address, setup_static_ip_netmask, setup_static_ip_gateway, setup_static_ip_dns1, setup_static_ip_dns2, setup_apply_dates, setup_manufacturing_date, setup_commissioning_date):
    result = wbms_result.WAITING
    timeout = 60
    start = time.monotonic()
    while (((result != wbms_result.ERROR) & (result != wbms_result.OK) & (result != wbms_result.TIMEOUT))):
        if time.monotonic() - start > timeout:
            raise TimeoutError("BMU Setup could not applied")
        result = wbms_apply_setup(setup_can_baudrate, setup_can_node_id, setup_bluetooth_mode, setup_network_mode, setup_static_ip_address, setup_static_ip_netmask, setup_static_ip_gateway, setup_static_ip_dns1, setup_static_ip_dns2, setup_apply_dates, setup_manufacturing_date, setup_commissioning_date)
    print(result)  

can_baudrate = wbms_can_baudrate(int(input("\nEnter Baudrate: ")))
print(can_baudrate)
node_id = int(input("\nEnter node id: "))
bluetooth_mode = wbms_ble_mode(int(input("\nEnter bluetooth mode: ")))
print(bluetooth_mode)
network_mode = wbms_network_mode(int(input("\nEnter network mode: ")))
print(network_mode)
dates_enabled = input("\nConfigure dates (Y/N): ")

if(network_mode == wbms_network_mode.STATIC_IP):
    static_ip_address = input("\nEnter Static IP address: ")
    static_ip_netmask = input("\nEnter Static IP netmask: ")
    static_ip_gateway = input("\nEnter Static IP gateway: ")
    static_ip_dns1 = input("\nEnter Static IP DNS 1: ")
    static_ip_dns2 = input("\nEnter Static IP DNS 2: ")
else:
    static_ip_address = "0.0.0.0"
    static_ip_netmask = "0.0.0.0"
    static_ip_gateway = "0.0.0.0"
    static_ip_dns1 = "0.0.0.0"
    static_ip_dns2 = "0.0.0.0"

if(dates_enabled == "Y"):
    manufacturing_date = input("\nEnter Manufacturing date (DD/MM/YY): ")
    commissioning_date = input("\nEnter Commissioning date (DD/MM/YY): ")
    apply_dates = "1"
else:
    manufacturing_date = "01/01/00"
    commissioning_date = "01/01/00"
    apply_dates = "0"

apply_bmu_setup(can_baudrate, node_id, bluetooth_mode, network_mode, static_ip_address, static_ip_netmask, static_ip_gateway, static_ip_dns1, static_ip_dns2, apply_dates, manufacturing_date, commissioning_date)