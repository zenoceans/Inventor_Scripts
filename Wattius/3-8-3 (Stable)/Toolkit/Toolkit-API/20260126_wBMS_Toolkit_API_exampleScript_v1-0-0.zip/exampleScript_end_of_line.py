from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *
import subprocess
import sys
import time
import os
import urllib.parse
import requests

def upload_configuration(config_path):
    result = wbms_result.WAITING
    timeout = 90
    start = time.monotonic()
    while (((result != wbms_result.ERROR) & (result != wbms_result.OK) & (result != wbms_result.TIMEOUT))):
        if time.monotonic() - start > timeout:
            raise TimeoutError("Configuration could not uploaded")
        result = wbms_upload_config(config_path)
    print(result)

def apply_bmu_setup(setup_can_baudrate, setup_can_node_id, setup_bluetooth_mode, setup_network_mode, setup_static_ip_address, setup_static_ip_netmask, setup_static_ip_gateway, setup_static_ip_dns1, setup_static_ip_dns2, setup_apply_dates, setup_manufacturing_date, setup_commissioning_date):
    result = wbms_result.WAITING
    timeout = 60
    start = time.monotonic()
    while (((result != wbms_result.ERROR) & (result != wbms_result.OK) & (result != wbms_result.TIMEOUT))):
        if time.monotonic() - start > timeout:
            raise TimeoutError("BMU Setup could not applied")
        result = wbms_apply_setup(setup_can_baudrate, setup_can_node_id, setup_bluetooth_mode, setup_network_mode, setup_static_ip_address, setup_static_ip_netmask, setup_static_ip_gateway, setup_static_ip_dns1, setup_static_ip_dns2, setup_apply_dates, setup_manufacturing_date, setup_commissioning_date)
    print(result)  

## BMU type
bmu_type = input("Select BMU type (R24, R32, MX, MX-PRO, HX): ")

## Toolkit
toolkit_path = input("Enter Toolkit path: ")

## Credentials 
toolkit_credential_user = input("Enter User: ")
toolkit_credential_password = input("Enter Password: ")

## Firmware
data_validation = False
while data_validation == False:
    safety_firmware_path = input("Introduce safety firmware path:")
    if (os.path.exists(safety_firmware_path) == True):
        data_validation = True
    else:
        print("Invalid input, try again")
        data_validation = True

if (bmu_type == "HX"):
    data_validation = False
    while data_validation == False:
        gateway_firmware_path = input("Introduce gateway firmware path:")
        if (os.path.exists(gateway_firmware_path) == True):
            data_validation = True
        else:
            print("Invalid input, try again")
            data_validation = True
else:
    gateway_firmware_path = ""

## Connection
connection_mode = input("Enter connection mode (USB or CAN): ")
if (connection_mode == "CAN"):
    data_validation = False
    while data_validation == False:
        input_data = input("What USB to CAN converter are you using? (KVASER or PEAK): ")
        if input_data == 'KVASER':
            can_convert_type = wbms_can_converter.KVASER
            data_validation = True
        elif input_data == 'PEAK':
            can_convert_type = wbms_can_converter.PEAK
            data_validation = True
        else:
            print("Invalid input, try again")
            data_validation = False
    is_default_can_config = input("Shall be used the default CAN bus connection settings? (Y/N): ")
    if (is_default_can_config == "N"):
        data_validation = False
        while data_validation == False:
            input_data = input("What baudrate are you using in kbps? (50, 100, 125, 250, 500, 1000): ")
            if input_data == '50':
                can_baudrate = wbms_can_baudrate.CAN_50kbps
                data_validation = True
            elif input_data == '100':
                can_baudrate = wbms_can_baudrate.CAN_100kbps
                data_validation = True
            elif input_data == '125':
                can_baudrate = wbms_can_baudrate.CAN_125kbps
                data_validation = True
            elif input_data == '250':
                can_baudrate = wbms_can_baudrate.CAN_250kbps
                data_validation = True
            elif input_data == '500':
                can_baudrate = wbms_can_baudrate.CAN_500kbps
                data_validation = True
            elif input_data == '1000':
                can_baudrate = wbms_can_baudrate.CAN_1000kbps
                data_validation = True
            else:
                print("Invalid input, try again")
                data_validation = False
        data_validation = False
        while data_validation == False:
            input_data = input("Enter CAN node ID: ")
            if int(input_data) < 48:
                data_validation = False
            elif int(input_data) > 63:
                data_validation = False
            else:
                can_node_id = int(input_data)
                data_validation = True
    else:
        can_baudrate = wbms_can_baudrate.CAN_250kbps
        can_node_id = 54

## Configuration
config_path = input("Enter Configuration file path: ")

## BMU Setup
setup_can_baudrate = wbms_can_baudrate(int(input("Enter Baudrate: ")))
setup_can_node_id = int(input("Enter node id: "))
setup_bluetooth_mode = wbms_ble_mode(int(input("Enter bluetooth mode: ")))
if (bmu_type == "HX"):
    setup_network_mode = wbms_network_mode(int(input("Enter network mode: ")))
else:
    setup_network_mode = wbms_network_mode.DISABLE
setup_dates_enabled = input("Configure dates (Y/N): ")

if(setup_network_mode == wbms_network_mode.STATIC_IP):
    setup_static_ip_address = input("Enter Static IP address: ")
    setup_static_ip_netmask = input("Enter Static IP netmask: ")
    setup_static_ip_gateway = input("Enter Static IP gateway: ")
    setup_static_ip_dns1 = input("Enter Static IP DNS 1: ")
    setup_static_ip_dns2 = input("Enter Static IP DNS 2: ")
else:
    setup_static_ip_address = "0.0.0.0"
    setup_static_ip_netmask = "0.0.0.0"
    setup_static_ip_gateway = "0.0.0.0"
    setup_static_ip_dns1 = "0.0.0.0"
    setup_static_ip_dns2 = "0.0.0.0"

if(setup_dates_enabled == "Y"):
    setup_manufacturing_date = input("Enter Manufacturing date (DD/MM/YY): ")
    setup_commissioning_date = input("Enter Commissioning date (DD/MM/YY): ")
    setup_apply_dates = "1"
else:
    setup_manufacturing_date = "01/01/00"
    setup_commissioning_date = "01/01/00"
    setup_apply_dates = "0"

## MQTT certificates
if (setup_network_mode != wbms_network_mode.DISABLE):
    upload_mqtt_certificates = input("Do you want to upload MQTT certificates (Y/N): ")
    if (upload_mqtt_certificates == "Y"):
        mqtt_url = input("Enter MQTT stripURL: ").strip()
        pem_path = input("Enter Server Certificate (.pem) path: ")
        crt_path = input("Enter Client Certificate (.crt) path: ")
        key_path = input("Enter Client key (.key) path: ")
else:
    upload_mqtt_certificates = "N"

## MQTT connection settings
if (setup_network_mode != wbms_network_mode.DISABLE):
    if (upload_mqtt_certificates == "Y"):
        upload_mqtt_connection_settings = input("Do you want to upload MQTT connection settings (Y/N): ")
        if (upload_mqtt_connection_settings == "Y"):
            mqtt_conn_settings_measurements_events = input("Send Measurements and Events? (Y/N): ")
            if (mqtt_conn_settings_measurements_events == "Y"):
                mqtt_conn_settings_measurements_events = "1"
            else:
                mqtt_conn_settings_measurements_events = "0"
            mqtt_conn_settings_remote_toolkit_connection = input("Enable remote Toolkit connection? (Y/N): ")
            if (mqtt_conn_settings_remote_toolkit_connection == "Y"):
                mqtt_conn_settings_remote_toolkit_connection = "1"
            else:
                mqtt_conn_settings_remote_toolkit_connection = "0"
            mqtt_conn_settings_offline_cache = input("Enable offline cache (beta)? (Y/N): ")
            if (mqtt_conn_settings_offline_cache == "Y"):
                mqtt_conn_settings_offline_cache = "1"
            else:
                mqtt_conn_settings_offline_cache = "0"

## Start process
print("****************************** OPENING TOOLKIT *****************************")
proc = subprocess.Popen([toolkit_path])

try:
    if (wbms_toolkit_api_poll() == False):
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        sys.exit()
    
    ## Sign in
    print("******************************* SIGN IN *******************************")
    log_in_result = wbms_sign_in(toolkit_credential_user, toolkit_credential_password)
    if (log_in_result != wbms_result.OK):
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        sys.exit()

    ## Connect to BMU
    print("************************** CONNECTING TO BMU **************************")
    if (connection_mode == "USB"):
        print(wbms_set_connection_usb())
    elif (connection_mode == "CAN"):
        print(wbms_set_connection_can(can_convert_type, can_baudrate, can_node_id, wbms_can_toolkit_refresh.FAST))

    ## Start Updating firmware
    print("************************** UPDATING SAFETY FIRMWARE **************************")
    print(wbms_update_firmware(safety_firmware_path))

    if(gateway_firmware_path != ""):
        ## Connect to BMU
        print("************************** CONNECTING TO BMU **************************")
        if (connection_mode == "USB"):
            print(wbms_set_connection_usb())
        elif (connection_mode == "CAN"):
            print(wbms_set_connection_can(can_convert_type, can_baudrate, can_node_id, wbms_can_toolkit_refresh.FAST))

        ## Start Updating firmware
        print("************************** UPDATING GATEWAY FIRMWARE **************************")
        print(wbms_update_firmware(gateway_firmware_path))
        time.sleep(5)
    
    ## Connect to BMU
    print("************************** CONNECTING TO BMU **************************")
    if (connection_mode == "USB"):
        print(wbms_set_connection_usb())
    elif (connection_mode == "CAN"):
        print(wbms_set_connection_can(can_convert_type, can_baudrate, can_node_id, wbms_can_toolkit_refresh.FAST))

    ## Apply BMU setup
    print("************************** APPLYING BMU SETUP **************************")
    apply_bmu_setup(setup_can_baudrate, setup_can_node_id, setup_bluetooth_mode, setup_network_mode, setup_static_ip_address, setup_static_ip_netmask, setup_static_ip_gateway, setup_static_ip_dns1, setup_static_ip_dns2, setup_apply_dates, setup_manufacturing_date, setup_commissioning_date)

    ## Upload configuration
    print("************************** UPLOADING CONFIGURATION **************************")
    upload_configuration(config_path)
    time.sleep(10)

    ## Get configuration CRC
    print("************************** GETTING CONFIGURATION CRC **************************")
    result = wbms_get_config_crc()
    timeout = 30
    start = time.monotonic()
    while (result == wbms_result.WAITING):
        if time.monotonic() - start > timeout:
            raise TimeoutError("Config CRC could not be read")
        result = wbms_get_config_crc()
    if(result == "FAILURE"):
        print(result)
    else:
        print("Configuration CRC (dec):" + str(int(result)))
        print("Configuration CRC (hex):" + str(hex(int(result))))

    ## Gateway configuration
    if (upload_mqtt_certificates == "Y"):
        ## Get IP
        print("************************** GETTING IP **************************")
        timeout = 30
        start = time.monotonic()
        result = wbms_result.OK
        ip_address = "0.0.0.0"
        while ((result == wbms_result.WAITING) | (result == wbms_result.OK) | (ip_address == "0.0.0.0")):
            if time.monotonic() - start > timeout:
                raise TimeoutError("IP don't get in time")
            result = wbms_get_ip()
            if ((result != wbms_result.WAITING) & (result != wbms_result.OK)):
                ip_address_parts = result.decode("utf-8").split('.')
                ip_address = str(int(ip_address_parts[0])) + "." + str(int(ip_address_parts[1])) + "." + str(int(ip_address_parts[2])) + "." + str(int(ip_address_parts[3]))
        
        print("IP: " + ip_address)
        url = f"http://{ip_address}"

        ## Upload MQTT certificates
        print("************************** UPLOADING MQTT CERTIFICATES **************************")
        with open(pem_path, "rb") as f: pem_cert_txt    = f.read()
        with open(crt_path, "rb") as f: crt_cert_txt    = f.read()
        with open(key_path, "rb") as f: key_client_txt  = f.read()

        pem_cert        = pem_cert_txt.decode("utf-8")
        crt_cert        = crt_cert_txt.decode("utf-8")
        key_client      = key_client_txt.decode("utf-8")

        pem             = urllib.parse.quote(pem_cert, safe=";/?:@&=+$,-_.!~*'()#")
        crt             = urllib.parse.quote(crt_cert, safe=";/?:@&=+$,-_.!~*'()#")
        key             = urllib.parse.quote(key_client, safe=";/?:@&=+$,-_.!~*'()#")

        mqtt_url_url    = url + "/api/v1/mcu2/config/mqttBroker?content="      + mqtt_url
        pem_url         = url + "/api/v1/mcu2/config/servercert?content="   + pem
        crt_url         = url + "/api/v1/mcu2/config/clientcert?content="   + crt
        key_url         = url + "/api/v1/mcu2/config/clientkey?content="    + key

        # 1) Upload Server Certificate (.pem)
        try:
            r_pem = requests.get(pem_url, timeout=5)
            if r_pem.status_code == 200:
                print(f"(Server CERT (.pem)\t\t-> {r_pem.text.strip()}")
            else:
                print(f"⚠️ Server CERT failed: HTTP {r_pem.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"❌ Error saving Server CERT: {e}")

        # 2) Upload Client Certificate (.crt)
        try:
            r_crt = requests.get(crt_url, timeout=5)
            if r_crt.status_code == 200:
                print(f"Client CERT (.crt)\t\t-> {r_crt.text.strip()}")
            else:
                print(f"⚠️ Client CERT failed: HTTP {r_crt.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"❌ Error saving Client CERT: {e}")

        # 3) Upload Client Key (.key)
        try:
            r_key = requests.get(key_url, timeout=5)
            if r_key.status_code == 200:
                print(f"(Client KEY (.key)\t\t-> {r_key.text.strip()}")
            else:
                print(f"⚠️ Client KEY failed: HTTP {r_key.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"❌ Error saving Client KEY: {e}")

        # 4) Save MQTT URL
        try:
            r_mqtt_url = requests.get(mqtt_url_url, timeout=5)
            if r_mqtt_url.status_code == 200:
                print(f"MQTT URL\t\t\t-> {r_mqtt_url.text.strip()}")
            else:
                print(f"⚠️ MQTT URL failed: HTTP {r_mqtt_url.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"❌ Error saving MQTT URL: {e}")

        if (upload_mqtt_connection_settings == "Y"):
            mqtt_connection_settings_url = url + "/api/v1/mcu2/config/flags?measurements_events=" + mqtt_conn_settings_measurements_events + "&mqtt_toolkit_connection=" + mqtt_conn_settings_remote_toolkit_connection + "&sd_cache=" + mqtt_conn_settings_offline_cache
            try:
                r_mqtt_conn_settings = requests.get(mqtt_connection_settings_url, timeout=5)
                if r_mqtt_conn_settings.status_code == 200:
                    print(f"MQTT connection settings\t\t-> {r_mqtt_conn_settings.text.strip()}")
                else:
                    print(f"⚠️ MQTT connection settings failed: HTTP {r_mqtt_conn_settings.status_code}")
            except requests.exceptions.RequestException as e:
                print(f"❌ Error saving MQTT connection settings: {e}")

    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
except KeyboardInterrupt:
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
