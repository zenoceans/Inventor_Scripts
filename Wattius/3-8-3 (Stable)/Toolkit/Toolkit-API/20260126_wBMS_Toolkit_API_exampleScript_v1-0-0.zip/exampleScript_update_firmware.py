from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *

print(wbms_update_firmware(input("\nEnter Firmware File path: ")))