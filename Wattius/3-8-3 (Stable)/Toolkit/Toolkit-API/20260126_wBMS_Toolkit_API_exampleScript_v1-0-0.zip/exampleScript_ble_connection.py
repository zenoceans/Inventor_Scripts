from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *

device = int(input("\nDevice ID: "))
print(wbms_set_connection_bluetooth(device))