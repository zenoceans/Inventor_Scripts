from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *

print(wbms_set_connection_mqtt(input("\nEnter BMU Serial Number (always 12 digits. i.e. 000541001000): "), input("\nEnter MQTT endpoint URL: "), input("\nEnter Path to certificate (.pfx): "), input("\nEnter authentication certificate password: ")))