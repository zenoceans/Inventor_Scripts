from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *
import time

result = wbms_get_config_crc()
timeout = 30
start = time.monotonic()
while (result == wbms_result.WAITING):
    if time.monotonic() - start > timeout:
        raise TimeoutError("Config CRC could not be read")
    result = wbms_get_config_crc()
if(result == "FAILURE"):
    print(result)
else:
    print("\nConfig CRC (dec):" + str(int(result)))
    print("\nConfig CRC (hex):" + str(hex(int(result))))