from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *
import time

def upload_configuration(config_path):
    result = wbms_result.WAITING
    timeout = 90
    start = time.monotonic()
    while (((result != wbms_result.ERROR) & (result != wbms_result.OK) & (result != wbms_result.TIMEOUT))):
        if time.monotonic() - start > timeout:
            raise TimeoutError("Configuration could not uploaded")
        result = wbms_upload_config(config_path)
    print(result)

config_file_path = input("\nEnter Config File path: ")
upload_configuration(config_file_path)