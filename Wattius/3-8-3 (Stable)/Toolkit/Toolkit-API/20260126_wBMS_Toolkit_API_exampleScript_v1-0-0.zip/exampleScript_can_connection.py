from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *

can_convert_type = wbms_can_converter(int(input("\nEnter CAN to USB Converter type: ")))
print(can_convert_type)
can_baudrate = wbms_can_baudrate(int(input("\nEnter Baudrate: ")))
print(can_baudrate)
node_id = int(input("\nEnter node id: "))
print(wbms_set_connection_can(can_convert_type, can_baudrate, node_id, wbms_can_toolkit_refresh.FAST))