from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *

print(wbms_sign_in(input("\nEnter User: "), input("\nEnter Password: ")))