from wbms_api.wbms_toolkit_api import *
from wbms_api.wbms_toolkit_types import *

print(wbms_start_logging(input("\nEnter csv file path: ")))