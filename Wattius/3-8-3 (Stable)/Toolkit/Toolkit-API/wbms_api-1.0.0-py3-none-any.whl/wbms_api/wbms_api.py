import socket
import select

def wbms_upload_config(config_file_path):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    file = open(config_file_path, "r")
    data = file.read()
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONF"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                print("Configuration is uploaded")
            elif data.decode('utf8') == "FAILURE":
                print("Configuration is not uploaded")
            else:
                print("Configuration error")
        else:
            print("Configuration timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")

def wbms_update_firmware(firmware_file_path):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    file = open(firmware_file_path, "r")
    data = file.read()
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "FIRM"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 180)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                print("Firmware is updated")
            elif data.decode('utf8') == "FAILURE":
                print("Firmware is not updated")
            else:
                print("Firmware error")
        else:
            print("Firmware timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")

def wbms_apply_setup(canbus_baudrate, canbus_id, bluetooth_mode):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    reserved = '0'
    data = reserved + canbus_baudrate + canbus_id.zfill(4) + bluetooth_mode
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "SETU"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                print("Setup is updated")
            elif data.decode('utf8') == "FAILURE":
                print("Setup is not updated")
            else:
                print("Setup error")
        else:
            print("Setup timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")

def wbms_set_connection_usb():
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    connection_mode = '0' #USB
    usb_com_port = '0' #Automatic
    usb_to_can_converter = '0' #Default KVASER
    usb_to_can_channel = '0' #automatic
    canbus_baudrate = '4' #default 250 kbps
    canbus_node_id = '54' #Default 54
    can_toolkit_refresh = '0' #Default fast
    device_id = '0' #Default
    data = connection_mode + usb_com_port + usb_to_can_converter + usb_to_can_channel + canbus_baudrate + canbus_node_id.zfill(4) + can_toolkit_refresh + device_id.zfill(4)
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONN"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                print("Device connected by USB")
            elif data.decode('utf8') == "FAILURE":
                print("Device not connected by USB")
            else:
                print("Connection error")
        else:
            print("Connection timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")

def wbms_set_connection_can(usb_to_can_converter, canbus_baudrate, canbus_node_id, can_toolkit_refresh):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    connection_mode = '5' #CAN
    usb_com_port = '0' #Automatic
    usb_to_can_channel = '0' #automatic
    device_id = '0' #Default
    data = connection_mode + usb_com_port + usb_to_can_converter + usb_to_can_channel + canbus_baudrate + canbus_node_id.zfill(4) + can_toolkit_refresh + device_id.zfill(4)
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONN"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                print("Device connected by CAN")
            elif data.decode('utf8') == "FAILURE":
                print("Device not connected by CAN")
            else:
                print("Connection error")
        else:
            print("Connection timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")

def wbms_set_connection_bluetooth(device_id):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    connection_mode = '4' #BLE
    usb_com_port = '0' #Automatic
    usb_to_can_converter = '0' #Default KVASER
    usb_to_can_channel = '0' #automatic
    canbus_baudrate = '4' #default 250 kbps
    canbus_node_id = '54' #Default 54
    can_toolkit_refresh = '0' #Default fast
    data = connection_mode + usb_com_port + usb_to_can_converter + usb_to_can_channel + canbus_baudrate + canbus_node_id.zfill(4) + can_toolkit_refresh + device_id.zfill(4)
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONN"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                print("Device connected by CAN")
            elif data.decode('utf8') == "FAILURE":
                print("Device not connected by CAN")
            else:
                print("Connection error")
        else:
            print("Connection timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")