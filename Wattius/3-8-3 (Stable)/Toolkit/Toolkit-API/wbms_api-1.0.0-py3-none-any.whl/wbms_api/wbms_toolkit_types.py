from enum import Enum

# General
class wbms_result(Enum):
     OK = 0
     ERROR = 1
     TIMEOUT = 2
     GETTING = 3
     WAITING = 4

# Connection
class wbms_connection_types(Enum):
     USB = 0
     MQTT = 1
     TCP = 2
     BLE = 4
     CAN = 5

# CAN
class wbms_can_baudrate(Enum):
     CAN_50kbps = 1
     CAN_100kbps = 2
     CAN_125kbps = 3
     CAN_250kbps = 4
     CAN_500kbps = 5
     CAN_1000kbps = 6

class wbms_can_converter(Enum):
     KVASER = 0
     PEAK = 1

class wbms_can_toolkit_refresh(Enum):
     FAST = 0
     SLOW = 1

# Bluetooth (BLE)
class wbms_ble_mode(Enum):
     ENABLED = 0
     DISABLED = 1

# Logging
class wbms_logging(Enum):
    STOP = 0
    START = 1

# Network
class wbms_network_mode(Enum):
    DISABLE = 0
    STATIC_IP = 1
    DHCP = 2