import socket
import select
import time
from wbms_api.wbms_toolkit_types import * #import all the types from wbms_toolkit_types

SECONDS_IN_A_MINUTE = 60
UPDATE_FIRMWARE_TIMEOUT = 6 * SECONDS_IN_A_MINUTE # 6 minutes

def wbms_toolkit_api_poll(timeout=10):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    start = time.time()
    while True:
        try:
            with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
                s.settimeout(1)
                s.connect((HOST, PORT))
            return True
        except OSError:
            if time.time() - start > timeout:
                return False
            time.sleep(0.2)

def wbms_upload_config(config_file_path):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    file = open(config_file_path, "r")
    data = file.read()
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONF"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 90)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Configuration is uploaded")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("Configuration is not uploaded")
            elif data.decode('utf8') == "GETTING":
                result = wbms_result.GETTING
                print("Configuration is not uploaded. The Toolkit is not ready to upload configuration.")
            elif data.decode('utf8') == "WAITING":
                result = wbms_result.WAITING
                print("Configuration is not uploaded. The Toolkit is not connected to a BMU.")
            else:
                result = wbms_result.ERROR
                print("Configuration error")
        else:
            result = wbms_result.TIMEOUT
            print("Configuration timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result

def wbms_update_firmware(firmware_file_path):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    file = open(firmware_file_path, "r")
    data = file.read()
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "FIRM"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], UPDATE_FIRMWARE_TIMEOUT)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Firmware is updated")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("Firmware is not updated")
            else:
                result = wbms_result.ERROR
                print("Firmware error")
        else:
            result = wbms_result.TIMEOUT
            print("Firmware timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result
    
def wbms_get_ip_format(ip:str):
    ip_parts = ip.split(".")
    if (len(ip_parts) != 4):
        print("Incorrect IP format")
        return wbms_result.ERROR, ""
    for p in ip_parts:
        if not p.isdigit():
            print("Incorrect IP format")
            return wbms_result.ERROR, ""
        
        num = int(p)
        if not 0 <= num <= 255:
            print("Incorrect IP format")
            return wbms_result.ERROR, ""
    
    formatted_ip = ip_parts[0].zfill(3) + ip_parts[1].zfill(3) + ip_parts[2].zfill(3) + ip_parts[3].zfill(3)
    return wbms_result.OK, formatted_ip

def wbms_get_date_format(date:str):
    date_parts = date.split("/")
    if (len(date_parts) != 3):
        print("Incorrect date format")
        return wbms_result.ERROR, ""
    for p in date_parts:
        if not p.isdigit():
            print("Incorrect date format")
            return wbms_result.ERROR, ""
        
    day = int(date_parts[0])
    if not 1 <= day <= 31:
        print("Incorrect date format")
        return wbms_result.ERROR, ""
    
    month = int(date_parts[1])
    if not 1 <= month <= 12:
        print("Incorrect date format")
        return wbms_result.ERROR, ""
    
    year = int(date_parts[2])
    if not 0 <= year <= 99:
        print("Incorrect date format")
        return wbms_result.ERROR, ""
    
    formatted_date = date_parts[0].zfill(2) + date_parts[1].zfill(2) + date_parts[2].zfill(2)
    return wbms_result.OK, formatted_date

def wbms_apply_setup(canbus_baudrate:wbms_can_baudrate, canbus_id:int, bluetooth_mode:wbms_ble_mode, network_mode:wbms_network_mode=wbms_network_mode.DISABLE, static_ip_address="0.0.0.0", static_ip_netwask="0.0.0.0", static_ip_gateway="0.0.0.0", static_ip_dns_1="0.0.0.0", static_ip_dns_2="0.0.0.0", import_dates="0", manufacturing_date="01/01/00", commissioning_date="01/01/00"):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    reserved = '0'

    result, formatted_static_ip_address = wbms_get_ip_format(static_ip_address)
    if (result == wbms_result.ERROR):
        print("Incorrect Static IP address format")
        return wbms_result.ERROR
    
    result, formatted_static_ip_netwask = wbms_get_ip_format(static_ip_netwask)
    if (result == wbms_result.ERROR):
        print("Incorrect Static IP address format")
        return wbms_result.ERROR
    
    result, formatted_static_ip_gateway = wbms_get_ip_format(static_ip_gateway)
    if (result == wbms_result.ERROR):
        print("Incorrect Static IP address format")
        return wbms_result.ERROR
    
    result, formatted_static_ip_dns_1 = wbms_get_ip_format(static_ip_dns_1)
    if (result == wbms_result.ERROR):
        print("Incorrect Static IP address format")
        return wbms_result.ERROR
    
    result, formatted_static_ip_dns_2 = wbms_get_ip_format(static_ip_dns_2)
    if (result == wbms_result.ERROR):
        print("Incorrect Static IP address format")
        return wbms_result.ERROR
    
    result, formatted_manufacturing_date = wbms_get_date_format(manufacturing_date)
    if (result == wbms_result.ERROR):
        print("Incorrect Manufacturing date format")
        return wbms_result.ERROR
    
    result, formatted_commissioning_date = wbms_get_date_format(commissioning_date)
    if (result == wbms_result.ERROR):
        print("Incorrect Commissioning date format")
        return wbms_result.ERROR

    data = reserved + str(canbus_baudrate.value) + str(canbus_id).zfill(4) + str(bluetooth_mode.value) + str(network_mode.value) + formatted_static_ip_address + formatted_static_ip_netwask + formatted_static_ip_gateway + formatted_static_ip_dns_1 + formatted_static_ip_dns_2 + import_dates + formatted_manufacturing_date + formatted_commissioning_date
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "SETU"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Setup is updated")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("Setup is not updated")
            elif data.decode('utf8') == "GETTING":
                result = wbms_result.GETTING
                print("Setup is not updated. The Toolkit is not ready to apply the Setup.")
            elif data.decode('utf8') == "WAITING":
                result = wbms_result.WAITING
                print("Setup is not uploaded. The Toolkit is not connected to a BMU.")
            else:
                result = wbms_result.ERROR
                print("Setup error")
        else:
            result = wbms_result.TIMEOUT
            print("Setup timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result

def wbms_set_connection_usb():
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    connection_mode = str(wbms_connection_types.USB.value) #USB
    usb_com_port = str(0) #Automatic
    usb_to_can_converter = str(wbms_can_converter.KVASER.value) #Default KVASER
    usb_to_can_channel = str(0) #automatic
    canbus_baudrate = str(wbms_can_baudrate.CAN_250kbps.value) #default 250 kbps
    canbus_node_id = str(54) #Default 54
    can_toolkit_refresh = str(wbms_can_toolkit_refresh.FAST.value) #Default fast
    device_id = str(0) #Default
    tcp_connection_settings = str(0).zfill(12)
    mqtt_connection_settings = str(0).zfill(24)
    data = connection_mode + usb_com_port + usb_to_can_converter + usb_to_can_channel + canbus_baudrate + canbus_node_id.zfill(4) + can_toolkit_refresh + device_id.zfill(4) + tcp_connection_settings + mqtt_connection_settings
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONN"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Device connected by USB")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("Device not connected by USB")
            else:
                result = wbms_result.ERROR
                print("Connection error")
        else:
            result = wbms_result.TIMEOUT
            print("Connection timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result

def wbms_set_connection_can(usb_to_can_converter:wbms_can_converter, canbus_baudrate:wbms_can_baudrate, canbus_node_id:int, can_toolkit_refresh:wbms_can_toolkit_refresh):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    connection_mode = str(wbms_connection_types.CAN.value) #CAN
    usb_com_port = str(0) #Automatic
    usb_to_can_channel = str(0) #automatic
    device_id = str(0) #Default
    tcp_connection_settings = str(0).zfill(12)
    mqtt_connection_settings = str(0).zfill(24)
    data = connection_mode + usb_com_port + str(usb_to_can_converter.value) + usb_to_can_channel + str(canbus_baudrate.value) + str(canbus_node_id).zfill(4) + str(can_toolkit_refresh.value) + device_id.zfill(4) + tcp_connection_settings + mqtt_connection_settings
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONN"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Device connected by CAN")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("Device not connected by CAN")
            else:
                result = wbms_result.ERROR
                print("Connection error")
        else:
            result = wbms_result.TIMEOUT
            print("Connection timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result

def wbms_set_connection_bluetooth(device_id:int):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    connection_mode = str(wbms_connection_types.BLE.value) #BLE
    usb_com_port = str(0) #Automatic
    usb_to_can_converter = str(wbms_can_converter.KVASER.value) #Default KVASER
    usb_to_can_channel = str(0) #automatic
    canbus_baudrate = str(wbms_can_baudrate.CAN_250kbps.value) #default 250 kbps
    canbus_node_id = str(54) #Default 54
    can_toolkit_refresh = str(wbms_can_toolkit_refresh.FAST.value) #Default fast
    tcp_connection_settings = str(0).zfill(12)
    mqtt_connection_settings = str(0).zfill(24)
    data = connection_mode + usb_com_port + usb_to_can_converter + usb_to_can_channel + canbus_baudrate + canbus_node_id.zfill(4) + can_toolkit_refresh + str(device_id).zfill(4) + tcp_connection_settings + mqtt_connection_settings
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONN"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 120)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Device connected by Bluetooth")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("Device not connected by Bluetooth")
            else:
                result = wbms_result.ERROR
                print("Connection error")
        else:
            result = wbms_result.TIMEOUT
            print("Connection timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result
    
def wbms_set_connection_tcp(tcp_ip:str):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    connection_mode = str(wbms_connection_types.TCP.value) #CAN
    usb_com_port = str(0) #Automatic
    usb_to_can_converter = str(wbms_can_converter.KVASER.value) #Default KVASER
    usb_to_can_channel = str(0) #automatic
    canbus_baudrate = str(wbms_can_baudrate.CAN_250kbps.value) #default 250 kbps
    canbus_node_id = str(54) #Default 54
    can_toolkit_refresh = str(wbms_can_toolkit_refresh.FAST.value) #Default fast
    device_id = str(0) #Default
    result, formatted_tcp_ip = wbms_get_ip_format(tcp_ip)
    if (result == wbms_result.ERROR):
        print("Incorrect IP format")
        return wbms_result.ERROR

    tcp_connection_settings = formatted_tcp_ip
    mqtt_connection_settings = str(0).zfill(24)

    data = connection_mode + usb_com_port + usb_to_can_converter + usb_to_can_channel + canbus_baudrate + canbus_node_id.zfill(4) + can_toolkit_refresh + device_id.zfill(4) + tcp_connection_settings + mqtt_connection_settings
            
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONN"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Device connected by TCP")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("Device not connected by TCP")
            else:
                result = wbms_result.ERROR
                print("Connection error")
        else:
            result = wbms_result.TIMEOUT
            print("Connection timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result

def wbms_set_connection_mqtt(serial_number:str, mqtt_endpoint_url:str, path_to_mqtt_certificate_path:str, authentication_password:str):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    connection_mode = str(wbms_connection_types.MQTT.value) #CAN
    usb_com_port = str(0) #Automatic
    usb_to_can_converter = str(wbms_can_converter.KVASER.value) #Default KVASER
    usb_to_can_channel = str(0) #automatic
    canbus_baudrate = str(wbms_can_baudrate.CAN_250kbps.value) #default 250 kbps
    canbus_node_id = str(54) #Default 54
    can_toolkit_refresh = str(wbms_can_toolkit_refresh.FAST.value) #Default fast
    device_id = str(0) #Default
    tcp_connection_settings = str(0).zfill(12)
    mqtt_connection_settings = serial_number.zfill(12) + str(len(mqtt_endpoint_url)).zfill(4) + mqtt_endpoint_url + str(len(path_to_mqtt_certificate_path)).zfill(4) + path_to_mqtt_certificate_path + str(len(authentication_password)).zfill(4) + authentication_password

    data = connection_mode + usb_com_port + usb_to_can_converter + usb_to_can_channel + canbus_baudrate + canbus_node_id.zfill(4) + can_toolkit_refresh + device_id.zfill(4) + tcp_connection_settings + mqtt_connection_settings
            
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "CONN"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 60)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Device connected by MQTT")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("Device not connected by MQTT")
            else:
                result = wbms_result.ERROR
                print("Connection error")
        else:
            result = wbms_result.TIMEOUT
            print("Connection timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result

def wbms_start_logging(csv_file_path):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    start_log_request = str(wbms_logging.START.value)
    file_path_length = str(len(csv_file_path.encode('utf8')))
    data = start_log_request + file_path_length.zfill(4) + csv_file_path
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "LOGG"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 10)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("wBMS-Toolkit starts logging")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("wBMS-Toolkit can not start logging")
            else:
                result = wbms_result.ERROR
                print("Logging error")
        else:
            result = wbms_result.TIMEOUT
            print("Logging timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result
    
def wbms_stop_logging():
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    start_log_request = str(wbms_logging.STOP.value)
    data = start_log_request 
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "LOGG"
        s.send(message_type.encode() + data.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 10)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("wBMS-Toolkit starts logging")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("wBMS-Toolkit can not start logging")
            else:
                result = wbms_result.ERROR
                print("Logging error")
        else:
            result = wbms_result.TIMEOUT
            print("Logging timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result
    
def wbms_force_ocv_soc():
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "FSOC"
        s.send(message_type.encode())
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 10)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("wBMS-Toolkit forces OCV SoC")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("wBMS-Toolkit cannot force OCV SoC")
            else:
                result = wbms_result.ERROR
                print("Force OCV SoC error")
        else:
            result = wbms_result.TIMEOUT
            print("Force OCV SoC timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result
    
def wbms_sign_in(user, password):
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "SIGN"
        codificate_user = "." + user
        codificate_password = "." + password
        new_codificate_user = ".\n" + user
        new_codificate_password = "\n" + password
        s.send(message_type.encode() + codificate_user.encode('utf8') + codificate_password.encode('utf8') + new_codificate_user.encode('utf8') + new_codificate_password.encode('utf8'))
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 10)
        if ready[0]:
            data = s.recv(7)
            if data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Signed in")
            elif data.decode('utf8') == "FAILURE":
                result = wbms_result.ERROR
                print("Incorrect credentials")
            else:
                result = wbms_result.ERROR
                print("Sign in error")
        else:
            result = wbms_result.TIMEOUT
            print("Sign in timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result

def wbms_get_config_crc():
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "GCRC"
        s.send(message_type.encode())
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 10)
        if ready[0]:
            data = s.recv(32)
            if data.decode('utf8') == "WAITING":
                result = wbms_result.WAITING
                print("Config CRC cannot be get. The Toolkit is not connected to a BMU.")
            else:
                result = data
                print("Config CRC get")
        else:
            result = wbms_result.TIMEOUT
            print("Get CRC config timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result

def wbms_get_ip():
    HOST = '::1'    # The server's hostname or IP address
    PORT = 11000    # The port used by the server
    with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        print("Connected to wBMS-Toolkit")
        message_type = "GEIP"
        s.send(message_type.encode())
        print("Sending information to wBMS-Toolkit")
        ready = select.select([s], [], [], 10)
        if ready[0]:
            data = s.recv(32)
            if data.decode('utf8') == "WAITING":
                result = wbms_result.WAITING
                print("IP cannot be get. The Toolkit is not connected to a BMU.")
            elif data.decode('utf8') == "CORRECT":
                result = wbms_result.OK
                print("Network is disabled. The IP is not assigned.")
            else:
                result = data
                print("IP get")
        else:
            result = wbms_result.TIMEOUT
            print("Get IP timeout")
        s.close()
        print("Disconnected from wBMS-Toolkit")
        return result